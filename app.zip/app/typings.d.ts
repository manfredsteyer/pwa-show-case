
declare var PouchDB: any