"use strict";
var BuchungenDoc = (function () {
    function BuchungenDoc() {
    }
    return BuchungenDoc;
}());
exports.BuchungenDoc = BuchungenDoc;
//# sourceMappingURL=buchungen-doc.js.map